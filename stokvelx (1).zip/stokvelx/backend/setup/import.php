<?php
/**
 * StokvelX – one-time database import for Railway.
 *
 * Disabled unless the Railway variable SETUP_KEY is set.
 * Visit: https://YOUR-APP.up.railway.app/backend/setup/import.php?key=YOUR_SETUP_KEY
 * Delete the SETUP_KEY variable on Railway once the import is done.
 */
header('Content-Type: text/plain; charset=UTF-8');

$setupKey = getenv('SETUP_KEY') ?: '';
if ($setupKey === '' || !hash_equals($setupKey, (string)($_GET['key'] ?? ''))) {
    http_response_code(404);
    exit('Not found');
}

require_once __DIR__ . '/../config/db.php';

// Refuse to wipe an existing install unless &force=1 is passed
$exists = $pdo->query("SHOW TABLES LIKE 'users'")->fetchColumn();
if ($exists && ($_GET['force'] ?? '') !== '1') {
    exit("Tables already exist – nothing done.\nAdd &force=1 to the URL to WIPE and re-import (all data will be lost).");
}

$sql = file_get_contents(__DIR__ . '/../database/schema-railway.sql');
// Strip full-line comments, then split on semicolons at line ends
$sql = preg_replace('/^\s*--.*$/m', '', $sql);
$statements = array_filter(array_map('trim', preg_split('/;\s*$/m', $sql)));

$ok = 0;
try {
    foreach ($statements as $stmt) {
        $pdo->exec($stmt);
        $ok++;
    }
} catch (PDOException $e) {
    http_response_code(500);
    exit("Failed after {$ok} statements:\n" . $e->getMessage() . "\n\nStatement:\n" . substr($stmt, 0, 300));
}

$users = $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
echo "Import complete: {$ok} statements run, {$users} users created.\n";
echo "Now delete the SETUP_KEY variable on Railway.";
