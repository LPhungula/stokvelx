# StokvelX Project — Claude Feedback & Preferences File
*Extracted from the full project conversation history. Reload this in future sessions.*

---

## 🎯 Delivery Preferences

### ZIP File Delivery
- **Always deliver as a single ZIP file** that extracts to one clean folder
- The folder inside the ZIP must be named `stokvelx` (not `stokvelx2` or anything else)
- User runs it by extracting and dropping into `C:\xampp\htdocs\`
- Reference example: the "mut-ict-portal" project was the gold standard format Luyanda showed
- **Never split delivery into multiple steps** — build everything first, then zip and present once

### "Just send the full website like the previous one"
- Luyanda's default request means: complete working ZIP, all files included, ready to extract and run
- Don't ask clarifying questions — just build it and deliver
- When asked to "continue" or "next step", check if a ZIP needs to be re-presented first

---

## 🏗️ Architecture & Stack Preferences

### Backend: Plain PHP + MySQL (NO frameworks)
- Switched from Node.js/Supabase to PHP explicitly: *"let's change the backend to be php like how we did the dotcom website"*
- **No Laravel, no Symfony, no Composer** — plain PDO only
- MySQL via phpMyAdmin for local dev (XAMPP/WAMP/MAMP)
- This mirrors a prior "DotCom website" project — keep architecture consistent

### Frontend: Static HTML/CSS/JS
- No React, no Vue, no build tools
- Single `style.css` file for all pages
- `api.js` → `nav.js` → `main.js` load order on every page
- Pages live in `/pages/` subfolder

### Hosting Stack (Production)
- **Frontend → Netlify** (stokvelx.netlify.app)
- **Backend PHP → Railway** (stokvelx-production.up.railway.app)
- **MySQL → Railway MySQL plugin**
- **Code → GitHub** (github.com/LPhungula/stokvelx)

---

## 🔒 Security Requirements

### Admin Panel Locking (3-layer guard)
Luyanda explicitly requested: *"lock the admin panel when the student has logged in, the admin only should view the panel"*

Three layers must ALL be present:
1. **Inline early script** at top of `admin.html` — fires before page renders, redirects students to `dashboard.html`
2. **`requireAdmin()`** called again in the main page script
3. **Sidebar nav** — Admin Panel link only injected when `role === 'admin'`

Students must NEVER see the Admin Panel link in the sidebar.

---

## 📁 Project File Structure

```
stokvelx/
├── index.html              ← Landing page
├── README.md
├── railway.json            ← Railway deployment config (minimal, no nixpacks)
├── css/style.css           ← Single shared stylesheet
├── js/
│   ├── api.js              ← API helper + auth guards + formatRand/formatDate
│   ├── nav.js              ← Injects sidebar (role-aware) + mobile nav
│   └── main.js             ← Toasts, modals, FAQ, chat, animations
├── pages/
│   ├── login.html, signup.html (3-step)
│   ├── dashboard.html, circles.html, join.html
│   ├── wallet.html, transactions.html, referrals.html
│   ├── chat.html, profile.html, settings.html
│   ├── help.html           ← Student user manual (11 sections)
│   └── admin.html          ← Admin only (triple-locked)
└── backend/
    ├── config/db.php       ← Uses getenv() for Railway, falls back to XAMPP defaults
    ├── database/schema.sql ← Full schema + seed data (13 users, 6 circles)
    ├── includes/
    │   ├── bootstrap.php   ← CORS headers BEFORE session_start(), JSON headers
    │   └── auth.php        ← requireLogin(), requireAdmin(), get_public_user()
    └── api/
        ├── auth/           ← login, logout, register, me
        ├── circles/        ← list, my-circles, join, create
        ├── payments/       ← pay (wallet deduction + referral bonus trigger)
        ├── wallet/         ← summary, add-money, withdraw
        ├── transactions/   ← list (paginated)
        ├── referrals/      ← stats
        ├── chat/           ← messages, send
        ├── profile/        ← update (GET + POST)
        └── admin/          ← stats, members
```

---

## 🐛 Deployment Bugs Found & Fixed

### Bug 1 — Database Connection Failure
- **Cause:** `db.php` had hardcoded `$DB_PASS = ''` for XAMPP but Railway MySQL needs env vars
- **Fix:** Use `getenv('MYSQLHOST')` etc. with `?: 'localhost'` fallback for local dev
- **Always do this** from the start when building for Railway deployment

### Bug 2 — CORS Blocking All API Calls (Critical)
- **Cause:** CORS headers were set AFTER `session_start()` in `bootstrap.php` — headers already sent
- **Fix:** Move ALL CORS header code to the very TOP of `bootstrap.php`, before `session_start()`
- **Allowed origins must include:** `https://stokvelx.netlify.app` AND `https://stirring-dodol-b8831a.netlify.app`
- **Always set CORS before session_start()** — non-negotiable rule

### Bug 3 — nixpacks.toml Crashed Railway
- **Cause:** Adding `nixpacks.toml` + `Procfile` + `apache.conf` to configure Apache broke Railway's auto-detection
- **Fix:** Delete nixpacks.toml, Procfile, apache.conf. Use minimal `railway.json` only
- **Railway auto-detects PHP** — don't override it with custom build configs

### Bug 4 — Nested ZIP Folder
- **Cause:** ZIP was created from inside the folder giving `stokvelx/stokvelx/` on extraction
- **Fix:** Always `cd` to the PARENT directory before running `zip -r stokvelx.zip stokvelx/`
- Always verify with: `unzip -l stokvelx.zip | grep '/$' | head -1`

### Bug 5 — Git README Conflict
- **Cause:** GitHub repo was created with a README, causing merge conflict on first push
- **Fix:** `git checkout --theirs README.md && git add README.md && git commit && git push`
- Or simpler: `git push -u origin main --force` on first push

### Bug 6 — Git Commands Jumbled on One Line
- Luyanda pasted multiple commands on one line which broke them
- Always present git commands one per line with explicit "press Enter" instructions

---

## 📋 Demo Account Data (Seed)

| Role | Email | Password | Notes |
|------|-------|----------|-------|
| Admin | admin@stokvelx.com | admin123 | id=1, role=admin |
| Student | sipho@student.uct.ac.za | password123 | id=2, UCT, wallet=R980 |
| All other students | various | password123 | ids 3-13 |

**Sipho (demo student) data:**
- Wallet balance: R980.00 (matches computed sum of wallet_transactions ✓)
- Active circles: Campus Builders (pos 4) + Future Leaders (pos 3)
- Completed: Campus Connect (received R1,500 payout)
- Upcoming payouts: R2,400 on 29 May + R2,320 on 5 June
- Referrals: 3 paid (R30 earned) + 2 pending

---

## 🌍 Deployment Steps (For Future Reference)

```
1. Push to GitHub:
   git add .
   git commit -m "message"
   git push origin main

2. Railway (backend + MySQL):
   - Connect GitHub repo → auto-deploys on push
   - Add MySQL plugin → copy 5 env variables to PHP service
   - Import schema via Railway Console:
     mysql -u $MYSQLUSER -p$MYSQLPASSWORD -h $MYSQLHOST --port=$MYSQLPORT $MYSQLDATABASE < /schema.sql

3. Netlify (frontend):
   - Import from GitHub → LPhungula/stokvelx
   - Leave all build settings blank
   - Auto-deploys on every git push

4. Connect them:
   - Get Railway URL from Settings → Networking
   - Update window.API_BASE in js/api.js
   - Push to GitHub → Netlify redeploys in ~60s
```

---

## 💡 Things To Do Differently Next Time

1. **Start with env-var-ready `db.php`** from day 1 — don't hardcode XAMPP defaults if deployment is planned
2. **Put CORS headers at the very top of bootstrap.php** before anything else
3. **Never add nixpacks.toml** to Railway PHP projects — it breaks auto-detection
4. **Name the ZIP folder correctly** — always zip from parent directory
5. **Create GitHub repo as empty** (no README) to avoid merge conflict on first push
6. **Always give git commands one per line** with explicit Enter instructions for Luyanda
7. **Validate schema.sql imports cleanly** before sending ZIP (run in MariaDB sandbox)
8. **Check wallet_balance arithmetic** — Sipho's balance must equal the SUM of his wallet_transactions
9. **Test CORS before declaring deployment done** — open F12 console and check for blocked requests
10. **api.js needs the Railway URL updated** before pushing to Netlify — don't forget this step

---

## 🎓 Academic Context

- **Student:** Luyanda Phungula (22315843@live.mut.ac.za)
- **Institution:** Mangosuthu University of Technology (MUT)
- **Module:** SDME400 — Advanced Diploma in ICT
- **Project:** StokvelX — South African student savings circle platform (startup)
- **GitHub:** github.com/LPhungula
- **Live URL:** https://stokvelx.netlify.app
- **Backend:** https://stokvelx-production.up.railway.app

---

## 📐 Design System

- **Primary green:** `#1DB954` (`--green`)
- **Dark green:** `#158a3e` (`--green-dark`)
- **Light green:** `#e8f8ee` (`--green-light`)
- **Purple:** `#6B4EFF` (`--purple`)
- **Dark bg:** `#0d1117` (`--dark`)
- **Fonts:** Syne (headings, 700/800) + DM Sans (body, 400/500)
- **Sidebar width:** 240px
- **App background:** `#f0f2f5`
- **Card background:** white with `1px solid #e5e7eb` border, `16px` border-radius

---

*Last updated: July 2026 | Project: StokvelX v1.0*
