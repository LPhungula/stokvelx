<?php
/**
 * StokvelX – router for PHP's built-in server (used on Railway only).
 * Blocks private folders/files; everything else is served normally.
 */
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if (preg_match('#^/(\.|backend/(config|includes|database)/|router\.php|Dockerfile|railway\.json|netlify\.toml|feedback\.md|README\.md)#i', $path)) {
    http_response_code(404);
    echo 'Not found';
    return true;
}
return false; // let the built-in server handle it (static file or .php)
