# StokvelX – Deploying to Railway + Netlify

- **Railway** runs the PHP backend + MySQL (it can also serve the whole site on its own).
- **Netlify** serves the HTML/CSS/JS and forwards every `/backend/*` request to Railway
  (see `netlify.toml`). The browser only ever talks to Netlify, so login cookies just work.

## 1. Push to GitHub
```
git add .
git commit -m "Railway + Netlify deployment fixes"
git push
```

## 2. Railway – MySQL
1. In your Railway project: **+ Create → Database → MySQL**.

## 3. Railway – the app service
1. **+ Create → GitHub Repo →** pick the stokvelx repo (skip if it already exists).
   Railway sees `railway.json` + `Dockerfile` and builds with them.
2. App service → **Variables → Raw Editor**, paste (if your DB service isn't named `MySQL`, use its name):
```
MYSQLHOST=${{MySQL.MYSQLHOST}}
MYSQLPORT=${{MySQL.MYSQLPORT}}
MYSQLUSER=${{MySQL.MYSQLUSER}}
MYSQLPASSWORD=${{MySQL.MYSQLPASSWORD}}
MYSQLDATABASE=${{MySQL.MYSQLDATABASE}}
SETUP_KEY=pick-any-long-random-text
```
3. App service → **Settings → Networking → Generate Domain**. If it asks for a port, enter **8080**.

## 4. Import the database (one time)
Open in your browser (your domain + your SETUP_KEY):
```
https://YOUR-APP.up.railway.app/backend/setup/import.php?key=pick-any-long-random-text
```
You should see `Import complete ... 13 users created`.
Then **delete the `SETUP_KEY` variable** on Railway.

Test: `https://YOUR-APP.up.railway.app/` – the full app should work here already.

## 5. Netlify
1. Open `netlify.toml` and make sure the `to = "https://.../backend/:splat"` line uses YOUR Railway domain. Push if you changed it.
2. Netlify → **Add new site → Import from GitHub** → stokvelx.
   Build command: *(empty)* · Publish directory: `.`
3. Open your Netlify URL → Login → use a demo account.

## Local (XAMPP) still works
Use `backend/database/schema.sql` in phpMyAdmin as before and open `http://localhost/stokvelx/`.
